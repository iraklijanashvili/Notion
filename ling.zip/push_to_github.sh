#!/bin/bash

# Configure Git
git config --local user.name "Irakli Janashvili"
git config --local user.email "iraklijanashvili1999@gmail.com"

# Create the README file if it doesn't exist
cat > README.md << 'EOL'
# LinguaQuest

An interactive language learning platform built with Next.js, React, and TypeScript.

## Features

- 🌐 Next.js 14 & server actions
- 🗣 AI Voices using Elevenlabs AI
- 🎨 Beautiful component system using Shadcn UI
- 🎭 Amazing characters
- 🔐 Auth using Clerk
- 🔊 Sound effects
- ❤️ Hearts system
- 🌟 Points / XP system
- 🔄 Practice old lessons to regain hearts
- 🏆 Leaderboard
- 🗺 Quests milestones
- 🛍 Shop system to exchange points with hearts
- 💳 Pro tier for unlimited hearts using Stripe
- 🏠 Landing page
- 📊 Admin dashboard React Admin
- 🌧 ORM using DrizzleORM
- 💾 PostgresDB using NeonDB
- 🚀 Deployment on Vercel
- 📱 Mobile responsiveness
EOL

# Add README to git
git add README.md
git commit -m "Update README with project description"

# Set remote URL with token
echo "Please enter your GitHub token:"
read -s GITHUB_TOKEN

# Set the remote URL with the token
git remote set-url origin "https://iraklijanashvili1999:${GITHUB_TOKEN}@github.com/iraklijanashvili1999/LinguaQuest.git"

# Push the code
git push -u origin main

echo "Push completed. You can now delete this script for security." 